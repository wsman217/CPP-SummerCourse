#include <iostream>

int main() {
    printf("Hello world\n");
    std::cout << "Hello World!" << std::endl;
    return 0;
}
